# Collections Plugins Directory

## Modules

- **ale_aos_ping**: Check SSH connectivity for an ALE OmniSwitch device.
- **ale_aos_command**: Send a command to an ALE OmniSwitch device.
- **ale_aos_config**: Send config commands from a file or a commands list to an ALE OmniSwitch device.
